package ud.example.practica005;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class Actividad2 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_actividad2);
    }
}